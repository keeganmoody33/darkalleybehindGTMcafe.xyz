# Dark Alley Behind GTM Cafe

**Keegan Moody's GTM Engineer Job Hunt OS — Built in Public**

Every role scored. Every application tracked. Nothing hidden.

---

## What This Is

A public job search dashboard for Keegan Moody's GTM Engineer job hunt. Built as a static web app because if you're going to search for a job building GTM systems, you should demonstrate you can build GTM systems.

The site tracks every role evaluated using a 6-dimension fit scoring rubric (0–100), shows application status in real-time, and publishes the methodology behind every decision. Raw, transparent, no PR filter.

**Owner:** Keegan Moody — [keeganmoody33@gmail.com](mailto:keeganmoody33@gmail.com) — [lecturesfrom.com/keeganmoody33](https://lecturesfrom.com/keeganmoody33)

---

## Live URLs

| Environment | URL |
|---|---|
| **Target domain** | [DarkAlleyBehindGTMCafe.xyz](https://DarkAlleyBehindGTMCafe.xyz) (DNS pending) |
| **Current deploy** | Perplexity Computer S3 static hosting |

---

## Tech Stack

| Layer | Choice | Why |
|---|---|---|
| HTML | Semantic HTML5, single file | No build step. Open index.html and it works. |
| CSS | Vanilla CSS + custom properties | Full design system in two files, no framework weight |
| JS | Vanilla ES6+ | Zero dependencies. Single app.js file. |
| Fonts | JetBrains Mono (Google Fonts) + Satoshi (Fontshare) | Terminal aesthetic + readable body copy |
| Hosting | Static file host (Cloudflare Pages / Netlify / Vercel) | No server needed |

**Dependencies: zero.** No npm packages required to run the site.

---

## File Structure

```
darkalley-cursor/
├── index.html              # The entire site — single page
├── base.css                # CSS reset + design tokens (spacing, type scale, radii)
├── style.css               # Component styles + color tokens + dark/light themes
├── app.js                  # All JS + TRACKER_DATA embedded array (~50 roles)
│
├── .cursorrules            # Cursor AI context — read this if you're in Cursor
├── README.md               # This file
├── .gitignore
├── package.json            # Dev scripts only (no build dependencies)
│
├── data/
│   ├── gtm_tracker.csv     # Source of truth for all tracker data
│   ├── hiring_managers.csv # Hiring manager research per company
│   └── resume.md           # Keegan Moody resume (source of truth for cover notes)
│
├── scripts/
│   └── csv-to-js.sh        # Regenerates TRACKER_DATA in app.js from CSV
│
└── docs/
    ├── SCORING_RUBRIC.md      # 6-dimension fit scoring methodology
    ├── WORKFLOW.md            # Full GTM Job Hunt OS workflow (9 steps)
    ├── HIRING_MANAGERS.md     # Hiring manager research organized by tier
    ├── APPLICATION_STATUS.md  # Current status of all 10 active applications
    └── COVER_NOTES.md         # All 10 custom 75-word cover notes
```

---

## Running Locally

**Option 1: Just open the file**
```bash
open index.html
# or double-click index.html in Finder/Explorer
```

**Option 2: Local server (recommended — avoids any CORS edge cases)**
```bash
npx serve .
# Opens at http://localhost:3000
```

**Option 3: VS Code Live Server**
Install the Live Server extension, right-click index.html → "Open with Live Server".

No build step. No `npm install`. No node_modules. It's just HTML/CSS/JS.

---

## Updating Tracker Data

The tracker data lives in two places:
1. `data/gtm_tracker.csv` — the source of truth (edit this)
2. `app.js` — the embedded `TRACKER_DATA` array (generated from CSV)

### To add or update roles:

**Step 1:** Edit `data/gtm_tracker.csv`. The columns are:
```
company, title, source, apply_url, remote, salary, posted_date, fit_score, action, match_reasons, gaps_risks, status
```

**Step 2:** Regenerate the JS data:
```bash
bash scripts/csv-to-js.sh
```

This outputs the new `TRACKER_DATA` block to stdout. Copy it and replace the existing `const TRACKER_DATA = [...]` in `app.js`.

**Step 3:** Reload `index.html` to verify the data renders correctly.

### Status values (valid options):
- `Not Started`
- `Applied`
- `Verification Pending`
- `Blocked - reCAPTCHA`
- `Blocked - Resume Upload`
- `Interviewing`
- `Rejected`
- `Offer`

---

## Design System Overview

The design system is entirely CSS custom properties defined in `base.css` and `style.css`.

### Color Palette (dark mode default)
| Token | Value | Use |
|---|---|---|
| `--color-bg` | `#0d0f12` | Page background |
| `--color-surface` | `#141720` | Cards, table |
| `--color-accent` | `#4ECDC4` | Muted signal teal — the brand color |
| `--color-text` | `#c8cdd8` | Primary text |
| `--color-text-muted` | `#6b7280` | Secondary text |
| `--color-green` | `#34d399` | Score ≥ 90, applied status |
| `--color-yellow` | `#fbbf24` | Score 75–89, review-first |
| `--color-blue` | `#60a5fa` | Applied status pill |
| `--color-purple` | `#a78bfa` | Interviewing status pill |
| `--color-red` | `#f87171` | Score < 75, rejected |

### Fonts
- `--font-display` / `--font-mono` → JetBrains Mono (headers, labels, badges, table headers)
- `--font-body` → Satoshi (paragraphs, descriptions)

### Theme Toggle
Toggle stored in `localStorage` as `data-theme`. Default is `dark`. The `<html>` element gets `data-theme="dark"` or `data-theme="light"`.

---

## Domain Setup: DarkAlleyBehindGTMCafe.xyz

The domain is registered. DNS needs to be pointed to the static host.

### Option A: Cloudflare Pages (recommended)

1. Push repo to GitHub
2. Go to Cloudflare Dashboard → Pages → Create project → Connect Git
3. Select repo, set build settings: **Framework preset = None**, build command = empty, output directory = `/`
4. Deploy
5. In Pages project → Custom domains → Add `DarkAlleyBehindGTMCafe.xyz`
6. If domain is on Cloudflare DNS, it auto-configures. Otherwise add CNAME:
   ```
   CNAME  @  your-project.pages.dev
   ```

### Option B: Netlify

1. Drag and drop the 4 site files (index.html, base.css, style.css, app.js) to [app.netlify.com/drop](https://app.netlify.com/drop)
2. Or connect GitHub repo for auto-deploy
3. Site Settings → Domain management → Add custom domain → `DarkAlleyBehindGTMCafe.xyz`
4. DNS: Add CNAME record:
   ```
   CNAME  @  your-site-name.netlify.app
   ```
   Or set nameservers to Netlify DNS for full management.

### Option C: Vercel

```bash
npx vercel
# Follow CLI prompts
```
Then in Vercel dashboard → Project Settings → Domains → Add `DarkAlleyBehindGTMCafe.xyz`.
DNS CNAME: `@ → cname.vercel-dns.com`

### DNS TTL Note
DNS propagation typically takes 5–30 minutes with Cloudflare, up to 48 hours with other registrars. Use [dnschecker.org](https://dnschecker.org) to verify propagation.

---

## Development Notes

- **No framework, ever.** The vanilla constraint is intentional.
- **Dark mode is default.** Don't add light-mode-first styles.
- **Use CSS vars.** Never hardcode `#4ECDC4` in new code. Always `var(--color-accent)`.
- **app.js is one file.** Don't split into modules. The simplicity is the feature.
- **TRACKER_DATA is large.** Edit in place, don't truncate.
- **fit_score is precise.** It comes from the 6-dimension scoring rubric in `docs/SCORING_RUBRIC.md`.

---

## Links

- **Portfolio:** [lecturesfrom.com/keeganmoody33](https://lecturesfrom.com/keeganmoody33)
- **Email:** [keeganmoody33@gmail.com](mailto:keeganmoody33@gmail.com)
- **Domain:** [DarkAlleyBehindGTMCafe.xyz](https://DarkAlleyBehindGTMCafe.xyz)
- **Scoring methodology:** [docs/SCORING_RUBRIC.md](docs/SCORING_RUBRIC.md)
- **Workflow:** [docs/WORKFLOW.md](docs/WORKFLOW.md)
- **Application status:** [docs/APPLICATION_STATUS.md](docs/APPLICATION_STATUS.md)
