#!/usr/bin/env bash
# csv-to-js.sh — Converts data/gtm_tracker.csv to TRACKER_DATA array for app.js
#
# Usage (run from project root):
#   bash scripts/csv-to-js.sh
#
# Output: Prints the TRACKER_DATA const block to stdout.
# To update app.js, copy the output and replace the existing TRACKER_DATA const.
#
# Or pipe directly to a temp file:
#   bash scripts/csv-to-js.sh > /tmp/tracker_data_new.js
#
# Requirements: python3 (standard on macOS and most Linux)

# Resolve project root relative to this script's location
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
CSV_FILE="$PROJECT_ROOT/data/gtm_tracker.csv"

if [ ! -f "$CSV_FILE" ]; then
  echo "Error: CSV file not found at $CSV_FILE" >&2
  exit 1
fi

python3 - "$CSV_FILE" << 'PYEOF'
import csv
import json
import sys

csv_path = sys.argv[1]

rows = []
with open(csv_path, newline='', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        # Convert fit_score to integer
        try:
            row['fit_score'] = int(row['fit_score'])
        except (ValueError, KeyError):
            pass

        # Normalize status — empty string becomes "Not Started"
        if not row.get('status', '').strip():
            row['status'] = 'Not Started'

        # Clean whitespace from all string fields
        for key in row:
            if isinstance(row[key], str):
                row[key] = row[key].strip()

        rows.append(row)

# Output as JS const
print('// ===== TRACKER DATA (embedded from CSV) =====')
print('// Source: data/gtm_tracker.csv')
print('// Regenerate: bash scripts/csv-to-js.sh')
print('const TRACKER_DATA = [')

for i, row in enumerate(rows):
    comma = ',' if i < len(rows) - 1 else ''
    print('  {')
    fields = [
        ('company', row.get('company', '')),
        ('title', row.get('title', '')),
        ('source', row.get('source', '')),
        ('apply_url', row.get('apply_url', '')),
        ('remote', row.get('remote', '')),
        ('salary', row.get('salary', '')),
        ('posted_date', row.get('posted_date', '')),
        ('fit_score', row.get('fit_score', 0)),
        ('action', row.get('action', '')),
        ('match_reasons', row.get('match_reasons', '')),
        ('gaps_risks', row.get('gaps_risks', '')),
        ('status', row.get('status', 'Not Started')),
    ]
    for j, (key, val) in enumerate(fields):
        field_comma = ',' if j < len(fields) - 1 else ''
        if isinstance(val, int):
            print(f'    "{key}": {val}{field_comma}')
        else:
            print(f'    "{key}": {json.dumps(val)}{field_comma}')
    print(f'  }}{comma}')

print('];')
print()
print(f'// Total roles: {len(rows)}')
PYEOF
