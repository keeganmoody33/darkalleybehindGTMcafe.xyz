# Hiring Manager Research

Compiled contacts for each company with an active application or high-fit role. Organized by fit score tier.

**Research methodology:** LinkedIn profile searches, company team pages, and job posting context. Confidence rated High/Medium/Low based on source quality and recency.

---

## Tier 1 — Auto-Apply (Score 90+)

### Dagster Labs — GTM Engineer (Score: 92)

| Contact | Title | LinkedIn | Confidence |
|---|---|---|---|
| **Joe DiBartolomeo** (Primary) | Head of Sales | [linkedin.com/in/josephdibartolomeo](https://www.linkedin.com/in/josephdibartolomeo) | High |
| **Selina Xilun Li** (Secondary) | Head of Operations | [linkedin.com/in/selinaxli](https://www.linkedin.com/in/selinaxli) | High |

**Notes:** Joe is listed on the Dagster company team page as Head of Sales with GTM leadership experience; oversees the sales team the role partners with. Selina oversees Revenue Operations per LinkedIn; also listed on company team page. Role works with RevOps.

---

### Slang AI — GTM Engineer - Revenue Operations (Score: 91)

| Contact | Title | LinkedIn | Confidence |
|---|---|---|---|
| **Alex Sambvani** (Primary) | Co-Founder and CEO | [linkedin.com/in/alexsambvani](https://www.linkedin.com/in/alexsambvani) | Medium |
| **Jeff Rudberg** (Secondary) | Sales Director | [linkedin.com/in/jeff-rudberg-835b1613](https://www.linkedin.com/in/jeff-rudberg-835b1613) | Low |

**Notes:** Small company — CEO is likely involved in GTM hires directly. Sales Director is the closest functional contact to the role.

---

## Tier 2 — Review-First (Score 75–89)

### G2 — GTM Engineer (Score: 88)

| Contact | Title | LinkedIn | Confidence |
|---|---|---|---|
| **Eric Gilpin** (Primary) | Chief Revenue Officer / President, GTM | [linkedin.com/in/ericgilpin](https://www.linkedin.com/in/ericgilpin) | High |
| **Paul Contino** (Secondary) | Chief Revenue Officer | [linkedin.com/in/paul-contino-b91b371](https://www.linkedin.com/in/paul-contino-b91b371) | Medium |

**Notes:** G2 job description links to Eric Gilpin's profile context as the GTM leader. Paul Contino is a secondary CRO contact. Job posting: [jobs.ashbyhq.com/g2/5c4a1e21-15a3-4122-9a9f-8681a7717242](https://jobs.ashbyhq.com/g2/5c4a1e21-15a3-4122-9a9f-8681a7717242).

---

### RevPartners — GTM Engineer (Score: 88)

| Contact | Title | LinkedIn | Confidence |
|---|---|---|---|
| **Hannah Rubin** (Primary) | Director of Revenue Operations | [linkedin.com/in/hannah-rubin](https://www.linkedin.com/in/hannah-rubin) | High |
| **Andrew Lydon** (Secondary) | Chief Operating Officer | [linkedin.com/in/lydon14](https://www.linkedin.com/in/lydon14) | Medium |

**Notes:** Hannah leads RevOps at RevPartners — the functional home of this role. Andrew as COO is the senior decision-maker.

---

### PandaDoc — GTM Engineer (Score: 86)

| Contact | Title | LinkedIn | Confidence |
|---|---|---|---|
| **Greta Stockdale** (Primary) | Senior Director of Revenue Operations | [linkedin.com/in/greta-stockdale-o-brien-03758560](https://www.linkedin.com/in/greta-stockdale-o-brien-03758560) | High |
| **Denis Malkov** (Secondary) | Vice President of Business Operations | [linkedin.com/in/funneldoctor](https://www.linkedin.com/in/funneldoctor) | High |

**Notes:** Greta leads RevOps at PandaDoc and matches the RevTech team that owns the GTM tech stack. Denis has extensive RevOps history at PandaDoc including Sr. Director Revenue Operations & Strategy.

---

### Unstructured — GTM Engineer, Operations (Score: 86)

| Contact | Title | LinkedIn | Confidence |
|---|---|---|---|
| **Orlando Nieves** (Primary) | Head of RevOps, Data, GTM Eng | [linkedin.com/in/orlando-n](https://www.linkedin.com/in/orlando-n) | High |

**Notes:** Orlando is the direct functional leader for this role — title literally says "GTM Eng." No secondary contact found. Single point of contact situation.

---

### Roboflow — RevOps GTM Engineer (Score: 86)

| Contact | Title | LinkedIn | Confidence |
|---|---|---|---|
| **Ashley Naumann Vonella** (Primary) | Head of GTM Strategy and Systems (Head of RevOps) | [linkedin.com/in/ashleyvonella](https://www.linkedin.com/in/ashleyvonella) | High |
| **Jeremy Powers** (Secondary) | Head of Sales | [linkedin.com/in/jeremypowers](https://www.linkedin.com/in/jeremypowers) | Medium |

**Notes:** Role reports to Head of RevOps; Ashley's profile and internal post confirm she owns this hire. LinkedIn Job: [linkedin.com/jobs/view/revops-gtm-engineer-at-roboflow-4391941019](https://www.linkedin.com/jobs/view/revops-gtm-engineer-at-roboflow-4391941019).

---

### SentiLink — Go-To-Market (GTM) Engineer (Score: 86)

| Contact | Title | LinkedIn | Confidence |
|---|---|---|---|
| **Kathleen Waid** (Primary) | Chief Revenue Officer | [linkedin.com/in/kwaid](https://www.linkedin.com/in/kwaid) | High |
| **Cole Bauer** (Secondary) | Head of GTM Ops | [linkedin.com/in/cole-bauer-48b688126](https://www.linkedin.com/in/cole-bauer-48b688126) | High |

**Notes:** Kathleen posted about the role on LinkedIn and has been building the revenue engine at SentiLink. Cole is Head of GTM Ops — directly mentioned in job post context. Both are highly relevant contacts.

---

### CaptivateIQ — GTM Engineer (Score: 86)

| Contact | Title | LinkedIn | Confidence |
|---|---|---|---|
| **Johnathan Warren** (Primary) | Director of Revenue Operations | [linkedin.com/in/johnathanwarren](https://www.linkedin.com/in/johnathanwarren) | High |
| **Sean Kashanchi** (Secondary) | Vice President of Sales | [linkedin.com/in/seankashanchi](https://www.linkedin.com/in/seankashanchi) | Medium |

**Notes:** Johnathan leads RevOps at CaptivateIQ — the direct functional owner of this role. Sean as VP Sales is the senior stakeholder.

---

### HockeyStack — Sales Engineer, GTM AI (Score: 86)

| Contact | Title | LinkedIn | Confidence |
|---|---|---|---|
| **James Hong** (Primary) | Head of Sales Engineering | [linkedin.com/in/jameshong1](https://www.linkedin.com/in/jameshong1) | High |
| **Albert Wong** (Secondary) | Head of Revenue Operations | [linkedin.com/in/albertlwong](https://www.linkedin.com/in/albertlwong) | Medium |

**Notes:** James leads the SE function and has hired SEs previously — direct hiring manager. Albert's RevOps background matches the GTM criteria and he's likely involved in the decision.

---

### Attentive — GTM Engineer (Score: 85)

| Contact | Title | LinkedIn | Confidence |
|---|---|---|---|
| **Erin Fitzpatrick** (Primary) | Senior Director, Revenue Operations | [linkedin.com/in/erin-fitzpatrick-ba6045b](https://www.linkedin.com/in/erin-fitzpatrick-ba6045b) | High |
| **Ellen Pratt** (Secondary) | VP, GTM Strategy and Enablement | [linkedin.com/in/ellen-pratt](https://www.linkedin.com/in/ellen-pratt) | Medium |

**Notes:** Erin is a current senior RevOps leader in the team the role reports into. Greenhouse job: [job-boards.greenhouse.io/attentive/jobs/4135931009](https://job-boards.greenhouse.io/attentive/jobs/4135931009).

---

## Additional Research (Not in Active Application Set)

### Vercel — GTM Engineer (Score: 84)

| Contact | Title | LinkedIn | Confidence |
|---|---|---|---|
| **Drew Bredvick** (Primary) | Director of GTM Engineering | [linkedin.com/in/drew-bredvick](https://www.linkedin.com/in/drew-bredvick) | High |
| **Renee Kelley (Psenka)** (Secondary) | Sr. Director, Head of Revenue Operations | [linkedin.com/in/rpsenka](https://www.linkedin.com/in/rpsenka) | Medium |

---

### Postscript — GTM Automation Engineer (Score: ~84)

| Contact | Title | LinkedIn | Confidence |
|---|---|---|---|
| **Caitlin Ferson** (Primary) | Senior Director of Revenue Operations | [linkedin.com/in/caitlinferson](https://www.linkedin.com/in/caitlinferson) | High |
| **Samuel Boyd** (Secondary) | VP of Sales | [linkedin.com/in/samuel-c-boyd](https://www.linkedin.com/in/samuel-c-boyd) | Medium |

---

### Toast — GTM Engineer, Marketing Operations AI Innovation (Score: ~84)

| Contact | Title | LinkedIn | Confidence |
|---|---|---|---|
| **Aaron Whittle** (Primary) | Sr Director, Global GTM Strategy and Operations | [linkedin.com/in/aaronewhittle](https://www.linkedin.com/in/aaronewhittle) | High |
| **Jonathan Vassil** (Secondary) | Chief Revenue Officer | [linkedin.com/in/jonathanvassil](https://www.linkedin.com/in/jonathanvassil) | Medium |

---

### Temporal Technologies — Senior GTM Engineer (Score: ~83)

| Contact | Title | LinkedIn | Confidence |
|---|---|---|---|
| **Michelle Isenberg** (Primary) | Head of Revenue Operations | [linkedin.com/in/misenberg](https://www.linkedin.com/in/misenberg) | High |
| **Lee Wright** (Secondary) | VP Revenue Operations | [linkedin.com/in/lwright72](https://www.linkedin.com/in/lwright72) | Medium |

---

## Research Notes

- All LinkedIn URLs are live as of March 2026 — verify before outreach as profiles change
- "High" confidence = contact's title/role directly matches what the JD describes as reporting structure or team ownership
- "Medium" confidence = plausible stakeholder based on org structure, not directly confirmed
- "Low" confidence = best available contact at the company, not confirmed as decision-maker for this specific role
- For outreach: Lead with Primary contact, CC Secondary only if relevant context exists
