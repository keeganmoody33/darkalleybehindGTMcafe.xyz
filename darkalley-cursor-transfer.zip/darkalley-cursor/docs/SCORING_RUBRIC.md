# Fit Scoring Rubric — GTM Engineer Job Hunt OS

**Total possible score: 100 points across 6 dimensions.**

Roles scoring 90+ are auto-apply. Roles scoring 75–89 are review-first. Roles below 75 are skipped.

---

## Dimension 1: Title Alignment (0–25 points)

The title is the single highest-signal indicator of role fit. Exact match = maximum points.

| Criteria | Points |
|---|---|
| Exact "GTM Engineer" in title | 25 |
| "GTM Engineer" with qualifier (e.g. "Founding GTM Engineer", "Senior GTM Engineer", "RevOps GTM Engineer") | 20 |
| Close variant (e.g. "GTM Engineer - Revenue Operations", "Sales Engineer, GTM AI") | 15–18 |
| Adjacent title with GTM in it (e.g. "GTM Systems Engineer", "GTM Automation Engineer", "Analytics Engineer, GTM") | 10–14 |
| GTM-adjacent with no engineer label (e.g. "Revenue Operations Engineer", "GTM Analyst") | 5–9 |
| Engineering role with GTM tangentially in the description only | 0–4 |

**Scoring notes:**
- "GTM Engineer" with a qualifier (Founding, Senior, Lead, RevOps) still scores 20 — the qualifier adds context, not penalty
- "Lead" or "Staff" titles get a penalty applied in Dimension 5 (Seniority), not here
- Sales Engineer roles with "GTM" in the title score 15–18 depending on how technical the GTM emphasis is

---

## Dimension 2: Technical GTM Systems Focus (0–20 points)

How central are GTM systems, RevOps tooling, and technical infrastructure to the role?

| Criteria | Points |
|---|---|
| Role is explicitly about building/owning GTM tech stack (Clay, Apollo, HubSpot, Salesforce, outbound infra, enrichment pipelines, ATS integrations) | 20 |
| B2B SaaS sales tech company where GTM engineering is core to the product | 15 |
| Other B2B SaaS with RevOps/GTM engineering focus | 10 |
| GTM role at a non-SaaS or consumer company | 5 |
| Peripheral GTM systems involvement | 2 |

**What counts as "technical GTM systems":**
- Building and maintaining the GTM tech stack (Clay, Apollo, HubSpot, Salesforce, Outreach, Salesloft, Gong, etc.)
- Writing Python/JS automation connecting data sources to CRM
- ETL pipelines for lead enrichment and data quality
- ATS integrations and outbound sequencing infrastructure
- Custom AI workflows for pipeline generation or lead qualification
- RevOps tooling administration at an engineering level (not just configuration)

---

## Dimension 3: Automation / AI Emphasis (0–20 points)

The target profile is "AI-native GTM Engineer." How much does the role lean into automation and AI tooling?

| Criteria | Points |
|---|---|
| AI explicitly in the title (e.g. "GTM AI Engineer", "Sales Engineer, GTM AI") | 20 |
| Automation explicitly in the title (e.g. "GTM Automation Engineer") | 18 |
| Job description centers on AI workflows, LLM integrations, or agentic systems for GTM | 17 |
| Job description includes automation-heavy GTM (Clay, enrichment at scale, sequencing automation) | 15 |
| Standard GTM engineering with some automation context | 5–10 |
| No automation/AI emphasis | 2 |

**Why this matters:**
Keegan's edge is AI-native GTM systems. At Mixmax he built a 9-agent agentic AI system and integrated Claude API into GTM workflows from day one. At Mobb AI he adopted MCP the week it launched. This dimension rewards roles where that edge compounds fastest.

---

## Dimension 4: Company Type (0–15 points)

Company context determines the ceiling for what you can build and how much the work matters.

| Criteria | Points |
|---|---|
| AI-native company (AI is the core product, not just a feature) | 15 |
| B2B SaaS / sales tech company (HubSpot, Apollo, Clay, Gong, etc.) | 12 |
| Other B2B SaaS (strong GTM motion, technical buyers) | 10 |
| B2B non-SaaS or mixed model | 7 |
| Consumer or non-technical company | 5 |
| Staffing firm, agency, or recruiter (role placed at an unknown company) | 3 |

**Notes:**
- "AI-native" means AI is the product, not just a marketing term (Dagster Labs, Unstructured, Mobb AI, Roboflow = AI-native; a legacy SaaS that added AI features = not AI-native)
- Sales tech companies (tools used in the GTM stack) score 12 because understanding the tools from the inside creates compounding expertise

---

## Dimension 5: Seniority Fit (0–10 points)

IC/mid-senior is the target. Not management, not VP, not entry-level.

| Criteria | Points |
|---|---|
| IC role: GTM Engineer, Senior GTM Engineer, Founding GTM Engineer | 10 |
| Tech Lead or Staff-level with strong IC component | 7 |
| Lead or Principal (primarily strategic, some IC) | 5 |
| Manager (people management required) | 2 |
| VP, Director, or C-level | 0 |
| Entry-level / coordinator | 3 |

**Notes:**
- "Founding GTM Engineer" scores 10 — it's IC, just with extra scope ownership
- If "Lead" means team lead without direct reports, it scores 7–8 depending on IC emphasis in JD
- "Head of GTM Engineering" = Director-equivalent = 2–3 points

---

## Dimension 6: Remote-First (0–10 points)

Keegan is based in Atlanta, GA. Fully remote is strongly preferred.

| Criteria | Points |
|---|---|
| Fully remote (no location requirement) | 10 |
| Remote with occasional travel (quarterly offsites, etc.) | 8 |
| Hybrid — remote-first with periodic in-office (1–2 days/week) | 5 |
| Hybrid — in-office-first (3+ days/week in a specific city) | 2 |
| In-office only / relocation required | 0 |

---

## Score Tiers and Actions

| Score | Tier | Action |
|---|---|---|
| 90–100 | Tier 1 | **Auto-apply** — Submit immediately via direct ATS link |
| 75–89 | Tier 2 | **Review-first** — Human review before submitting, custom note required |
| 74 and below | Tier 3 | **Skip** — Not worth the time investment at this stage |

---

## Scoring Examples

**Dagster Labs — GTM Engineer (score: 92)**
- Title alignment: 25 (exact)
- Technical GTM systems: 20 (data infra company, GTM tech stack role)
- Automation/AI: 17 (AI-native context, GTM automation)
- Company type: 15 (AI-native)
- Seniority: 10 (IC)
- Remote: 5 (yes, but score from source data)
- **Total: 92**

**HockeyStack — Sales Engineer, GTM AI (score: 86)**
- Title alignment: 18 (GTM AI variant, close but not exact)
- Technical GTM systems: 15 (sales tech company, GTM systems)
- Automation/AI: 20 (AI explicit in title)
- Company type: 15 (AI-native, attribution layer)
- Seniority: 10 (IC)
- Remote: 8 (yes)
- **Total: 86**

---

## Anti-Patterns (automatic score reduction)

These patterns reliably reduce fit score and should be weighted accordingly:

- **Analytics Engineer skew**: Roles where SQL/dbt depth is the core requirement (not GTM tooling) — reduces Dimension 1 and 2 scores
- **Staff/Lead seniority with mandatory team management**: Reduces Dimension 5 significantly
- **VP-level compensation ranges**: Usually signals the role is above the IC tier
- **Healthcare/compliance domain without relevant domain experience**: Moderate risk flag (not disqualifying, but noted)
- **Staffing/recruiter posting**: Reduces Dimension 4 (company type unknown)
- **Pre-sale focus**: Roles framed as sales engineering for the pre-sales motion (vs. building GTM infrastructure) — reduces Dimension 2
