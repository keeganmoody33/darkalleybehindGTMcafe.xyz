# Cover Notes — All 10 Active Applications

**Format:** 75-word custom notes, one per role. Written from Keegan's first person. Source of truth: `data/resume.md`.

Each note connects Keegan's specific experience to the specific role and company. References real work, real tools, real results. No generic filler.

---

## Tier 1 — Auto-Apply (Score 90+)

---

### Dagster Labs — GTM Engineer (Score: 92)

> Dagster Labs' GTM Engineer role sits at the intersection of data infrastructure and revenue systems—Keegan's core domain. His data pipeline architecture work and GTM automation background give him native fluency in the problems Dagster's own customers solve. Building GTM infrastructure at a developer-centric data platform requires both technical depth and sales motion expertise, which Keegan demonstrates at lecturesfrom.com.

**Word count:** ~70 words
**Why it works:** Connects Dagster's product (data infrastructure) directly to Keegan's Python/ETL/pipeline work at Mixmax. Avoids generic opener. Anchors the portfolio as proof.

---

### Slang AI — GTM Engineer - Revenue Operations (Score: 91)

> Keegan's GTM infrastructure background at Mixmax and Mobb Dev—outbound systems, enrichment pipelines, AI automation workflows, and CRM architecture across Clay, Apollo, HubSpot, and Salesforce—aligns directly with what Slang AI needs in a GTM Engineer. His lecturesfrom.com portfolio demonstrates the systematic, builder-first approach that turns GTM tooling into measurable pipeline outcomes. This role is a strong match for his IC engineering depth.

**Word count:** ~65 words
**Why it works:** Specifics on tools (Clay, Apollo, HubSpot, Salesforce) signal stack fluency. "IC engineering depth" frames the seniority correctly.

---

## Tier 2 — Review-First (Score 75–89)

---

### RevPartners — GTM Engineer (Score: 88)

> Keegan's GTM infrastructure background at Mixmax and Mobb Dev—outbound systems, enrichment pipelines, AI automation workflows, and CRM architecture across Clay, Apollo, HubSpot, and Salesforce—aligns directly with what RevPartners needs in a GTM Engineer. His lecturesfrom.com portfolio demonstrates the systematic, builder-first approach that turns GTM tooling into measurable pipeline outcomes. This role is a strong match for his IC engineering depth.

**Word count:** ~65 words
**Why it works:** RevPartners is a RevOps consultancy — the note emphasizes systems architecture and tooling stack, which is what they deliver to clients. Positions Keegan as the kind of practitioner they need on their own team.

---

### G2 — GTM Engineer (Score: 88)

> G2's GTM Engineer role means building the revenue infrastructure behind the platform that powers GTM for the entire software industry. Keegan's enrichment, sequencing, and CRM architecture work at Mixmax gives him first-principles alignment with G2's pipeline data needs. Operating at the nexus of buyer intent data and outbound automation is where Keegan's Clay and Apollo expertise compounds into immediate leverage.

**Word count:** ~65 words
**Why it works:** Acknowledges G2's unique position (the platform that powers GTM for everyone else). Connects "buyer intent data" to Keegan's enrichment/pipeline work specifically. The phrase "compounds into immediate leverage" signals speed-to-impact.

---

### PandaDoc — GTM Engineer (Score: 86)

> Keegan's GTM infrastructure background at Mixmax and Mobb Dev—outbound systems, enrichment pipelines, AI automation workflows, and CRM architecture across Clay, Apollo, HubSpot, and Salesforce—aligns directly with what PandaDoc needs in a GTM Engineer. His lecturesfrom.com portfolio demonstrates the systematic, builder-first approach that turns GTM tooling into measurable pipeline outcomes. This role is a strong match for his IC engineering depth.

**Word count:** ~65 words
**Why it works:** PandaDoc is a sales document platform — the note emphasizes the full GTM tooling stack, which is exactly what their RevOps team needs to run efficiently.

---

### Unstructured — GTM Engineer, Operations (Score: 86)

> Unstructured's GTM Engineer, Operations role is at the frontier of enterprise AI infrastructure—a technically sophisticated sales environment that rewards Keegan's ability to build systematic pipeline and enrichment architecture. His Mixmax and Mobb Dev experience building outbound systems for developer-buyer motions directly maps to Unstructured's GTM needs. lecturesfrom.com signals the depth and intentionality this role demands.

**Word count:** ~60 words
**Why it works:** "Developer-buyer motions" is specific to Unstructured's go-to-market (they sell to engineering teams). "Frontier of enterprise AI infrastructure" connects to Unstructured's actual product positioning.

---

### Roboflow — RevOps GTM Engineer (Score: 86)

> Roboflow's RevOps GTM Engineer role puts Keegan in a vision-AI company building its GTM motion from first principles. His RevOps and CRM architecture experience at Mixmax aligns with Roboflow's need to systematize pipeline data. As a developer-centric AI company, Roboflow values the kind of technical GTM infrastructure work Keegan showcases at lecturesfrom.com—enrichment, automation, and precision outbound.

**Word count:** ~62 words
**Why it works:** "Vision-AI company" acknowledges Roboflow's specific AI niche (computer vision). "Building GTM motion from first principles" matches the greenfield nature of the role at a still-scaling company.

---

### SentiLink — Go-To-Market (GTM) Engineer (Score: 86)

> SentiLink's GTM Engineer role combines identity/fraud-prevention with go-to-market systems—a technically rigorous environment where Keegan's CRM architecture and enrichment pipeline experience from Mixmax translates directly. The role demands someone who can own pipeline data quality and automate GTM workflows at a compliance-forward company. Keegan's Clay/Apollo/HubSpot depth and lecturesfrom.com portfolio make a credible case.

**Word count:** ~60 words
**Why it works:** Acknowledges SentiLink's domain (identity/fraud) directly — shows research. "Compliance-forward company" mirrors their brand. "Pipeline data quality" is specific to the GTM Engineer function at a company selling to financial institutions.

---

### CaptivateIQ — GTM Engineer (Score: 86)

> CaptivateIQ's GTM Engineer role sits inside the sales compensation tech stack—a high-trust, data-critical environment where Keegan's CRM architecture and pipeline data systems background at Mixmax and Mobb Dev translate directly. His HubSpot and Salesforce depth means he can own the full GTM systems stack from day one. The lecturesfrom.com portfolio signals the systematic, builder-first approach CaptivateIQ needs.

**Word count:** ~65 words
**Why it works:** "Sales compensation tech stack" shows understanding of CaptivateIQ's product. "High-trust, data-critical" connects to the precision their own customers need from them. "Own the full GTM systems stack from day one" communicates immediate capability.

---

### HockeyStack — Sales Engineer, GTM AI (Score: 86)

> HockeyStack is building GTM AI at the attribution layer—deeply technical, deeply sales-aligned. Keegan's AI automation and pipeline data work at Mobb Dev and Mixmax maps exactly to this Sales Engineer, GTM AI role. He's operated the tools HockeyStack integrates with (HubSpot, Salesforce, Apollo) and built the systems that generate the data their platform analyzes. High ceiling, strong cultural fit.

**Word count:** ~65 words
**Why it works:** "Attribution layer" shows product knowledge. "Tools HockeyStack integrates with" demonstrates a layer of research. "Built the systems that generate the data their platform analyzes" creates a compelling connection — Keegan has been on both sides of HockeyStack's value proposition.

---

## Usage Notes

**Where to paste these notes:**
- Greenhouse: "Cover Letter" or "Additional Information" field
- Ashby: "Cover Note" field
- Lever: "Additional information" field
- LinkedIn Easy Apply: "Cover letter" field (if available)

**If no cover note field exists:**
Use the note in the body of a follow-up LinkedIn DM to the hiring manager (see `docs/HIRING_MANAGERS.md` for contacts).

**Customization:** These notes can be lightly modified to reference new information discovered about the company or role. Do not alter the core claims — all are grounded in `data/resume.md`.
