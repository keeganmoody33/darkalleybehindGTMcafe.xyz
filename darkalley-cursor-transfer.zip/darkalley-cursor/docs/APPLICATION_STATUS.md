# Application Status — Active Applications

**Last updated:** March 30, 2026
**Total applications in progress:** 10
**Fully confirmed applied:** 1
**Pending verification:** 2
**Blocked (manual submit required):** 5
**Not yet submitted:** 2

---

## Status Key

| Status | Meaning |
|---|---|
| ✅ Applied | Submitted and confirmed with proof |
| ⏳ Verification Pending | Submitted but requires email verification code before confirmation |
| 🚫 Blocked | Technical blocker prevents submission — manual action required |
| 🔗 LinkedIn Only | No ATS found — must apply via LinkedIn Easy Apply |
| ❓ ATS Not Found | Listed on job board but no direct ATS link found |

---

## Applications — Full Detail

---

### 1. Unstructured
**Role:** GTM Engineer, Operations
**Fit Score:** 86 | **Action:** review-first
**Status:** ✅ **APPLIED**
**Method:** Lever ATS — confirmed submission
**Apply URL:** [linkedin.com/jobs/view/gtm-engineer-operations-at-unstructured-4388381035](https://www.linkedin.com/jobs/view/gtm-engineer-operations-at-unstructured-4388381035)
**Notes:** Applied via Lever. Submission confirmed. Proof: confirmation page screenshot captured.

---

### 2. Dagster Labs
**Role:** GTM Engineer
**Fit Score:** 92 | **Action:** auto-apply
**Status:** ⏳ **VERIFICATION PENDING**
**Method:** Greenhouse — email verification code required
**Apply URL:** [indeed.com/viewjob?jk=45a4c907ba0d95a7](https://www.indeed.com/viewjob?jk=45a4c907ba0d95a7)
**Notes:** Application submitted through Greenhouse. Waiting for verification email with code. Check keeganmoody33@gmail.com inbox for Greenhouse verification email and complete the verification step to confirm application. **Action required: complete email verification.**

---

### 3. PandaDoc
**Role:** GTM Engineer
**Fit Score:** 86 | **Action:** review-first
**Status:** ⏳ **VERIFICATION PENDING**
**Method:** Greenhouse — email verification code required
**Apply URL:** [linkedin.com/jobs/view/gtm-engineer-at-pandadoc-4369211319](https://www.linkedin.com/jobs/view/gtm-engineer-at-pandadoc-4369211319)
**Notes:** Application submitted through Greenhouse. Waiting for verification email. Check keeganmoody33@gmail.com for Greenhouse email and complete verification. **Action required: complete email verification.**

---

### 4. G2
**Role:** GTM Engineer
**Fit Score:** 88 | **Action:** review-first
**Status:** 🚫 **BLOCKED — reCAPTCHA**
**Method:** Ashby ATS
**Direct Apply URL:** [jobs.ashbyhq.com/g2/5c4a1e21-15a3-4122-9a9f-8681a7717242/application](https://jobs.ashbyhq.com/g2/5c4a1e21-15a3-4122-9a9f-8681a7717242/application)
**Notes:** reCAPTCHA prevents automated submission. Must be submitted manually in a real browser. Navigate to the direct link above and complete the application manually. Use the 75-word cover note from `docs/COVER_NOTES.md`.

---

### 5. Roboflow
**Role:** RevOps GTM Engineer
**Fit Score:** 86 | **Action:** review-first
**Status:** 🚫 **BLOCKED — reCAPTCHA**
**Method:** Ashby ATS
**Direct Apply URL:** [jobs.ashbyhq.com/roboflow/c878667f-01c3-4c44-8f1e-07c8e03423df/application](https://jobs.ashbyhq.com/roboflow/c878667f-01c3-4c44-8f1e-07c8e03423df/application)
**Notes:** reCAPTCHA prevents automated submission. Must be submitted manually in a real browser. Navigate to the direct link above and complete the application manually. Use the 75-word cover note from `docs/COVER_NOTES.md`.

---

### 6. SentiLink
**Role:** Go-To-Market (GTM) Engineer
**Fit Score:** 86 | **Action:** review-first
**Status:** 🚫 **BLOCKED — Resume Upload Failed**
**Method:** Ashby ATS
**Direct Apply URL:** [jobs.ashbyhq.com/sentilink/6f1933aa-fb99-4393-9beb-8832ca9daa1e/application](https://jobs.ashbyhq.com/sentilink/6f1933aa-fb99-4393-9beb-8832ca9daa1e/application)
**Notes:** Resume upload step failed — the file upload blocked submission completion. Must submit manually in a real browser. Navigate to the direct link above, upload resume manually, and complete the application. Use the 75-word cover note from `docs/COVER_NOTES.md`.

---

### 7. Slang AI
**Role:** GTM Engineer - Revenue Operations
**Fit Score:** 91 | **Action:** auto-apply
**Status:** 🔗 **LINKEDIN ONLY — No ATS Found**
**Method:** LinkedIn Easy Apply (only option found)
**LinkedIn URL:** [linkedin.com/jobs/view/gtm-engineer-revenue-operations-at-slang-ai-4380715014](https://www.linkedin.com/jobs/view/gtm-engineer-revenue-operations-at-slang-ai-4380715014)
**Notes:** No direct ATS link (Greenhouse/Ashby/Lever) found for this role. Only found via LinkedIn listing. Apply via LinkedIn Easy Apply. If Easy Apply doesn't show cover note field, check Slang AI's careers page directly at [slang.ai/careers](https://www.slang.ai/careers) for alternative submission path.

---

### 8. RevPartners
**Role:** GTM Engineer
**Fit Score:** 88 | **Action:** review-first
**Status:** 🔗 **LINKEDIN ONLY — No ATS Found**
**Method:** LinkedIn Easy Apply (only option found)
**LinkedIn URL:** [linkedin.com/jobs/view/gtm-engineer-at-revpartners-4382218617](https://www.linkedin.com/jobs/view/gtm-engineer-at-revpartners-4382218617)
**Notes:** No direct ATS link found. Apply via LinkedIn Easy Apply. If RevPartners uses a specific ATS, check their careers page. Use the 75-word cover note from `docs/COVER_NOTES.md` in the notes/cover letter field.

---

### 9. CaptivateIQ
**Role:** GTM Engineer
**Fit Score:** 86 | **Action:** review-first
**Status:** ❓ **ATS NOT FOUND — Lever Suspected, No Direct Link**
**Method:** Lever ATS suspected (CaptivateIQ uses Lever for other roles) — no direct link found
**Source URL:** [indeed.com/viewjob?jk=2933c05b3e8a52c9](https://www.indeed.com/viewjob?jk=2933c05b3e8a52c9)
**Notes:** Search for CaptivateIQ on Lever directly: `jobs.lever.co/captivateiq` — if the role appears there, apply via that link. Otherwise apply through Indeed or check CaptivateIQ's careers page at [captivateiq.com/company/careers](https://captivateiq.com/company/careers).

---

### 10. HockeyStack
**Role:** Sales Engineer, GTM AI
**Fit Score:** 86 | **Action:** review-first
**Status:** ❓ **ATS NOT FOUND — BuiltIn Listing Only**
**Method:** Not yet determined
**Source URL:** [indeed.com/q-gtm-engineer-l-remote-jobs.html](https://www.indeed.com/q-gtm-engineer-l-remote-jobs.html)
**Notes:** Not found on Ashby. Only source is BuiltIn listing and Indeed search results. Check HockeyStack's direct careers page and LinkedIn Jobs listing for direct ATS link. Try: [hockeystack.com/careers](https://hockeystack.com/careers).

---

## Manual Action Queue

These require Keegan to take action manually (in a real browser, not automated):

| Priority | Company | Action Required | URL |
|---|---|---|---|
| 1 | Dagster Labs | Complete email verification | Check keeganmoody33@gmail.com inbox |
| 2 | PandaDoc | Complete email verification | Check keeganmoody33@gmail.com inbox |
| 3 | G2 | Manual apply via Ashby | [jobs.ashbyhq.com/g2/5c4a1e21...](https://jobs.ashbyhq.com/g2/5c4a1e21-15a3-4122-9a9f-8681a7717242/application) |
| 4 | Roboflow | Manual apply via Ashby | [jobs.ashbyhq.com/roboflow/c878667f...](https://jobs.ashbyhq.com/roboflow/c878667f-01c3-4c44-8f1e-07c8e03423df/application) |
| 5 | SentiLink | Manual apply via Ashby | [jobs.ashbyhq.com/sentilink/6f1933aa...](https://jobs.ashbyhq.com/sentilink/6f1933aa-fb99-4393-9beb-8832ca9daa1e/application) |
| 6 | Slang AI | LinkedIn Easy Apply | [linkedin.com/jobs/view/...4380715014](https://www.linkedin.com/jobs/view/gtm-engineer-revenue-operations-at-slang-ai-4380715014) |
| 7 | RevPartners | LinkedIn Easy Apply | [linkedin.com/jobs/view/...4382218617](https://www.linkedin.com/jobs/view/gtm-engineer-at-revpartners-4382218617) |
| 8 | CaptivateIQ | Find ATS link + apply | Check jobs.lever.co/captivateiq |
| 9 | HockeyStack | Find ATS link + apply | Check hockeystack.com/careers |

---

## Proof Requirements

Before marking any role `Applied` in the tracker:
- Dagster Labs: Greenhouse confirmation email/page (after completing email verification)
- PandaDoc: Greenhouse confirmation email/page (after completing email verification)
- G2: Ashby confirmation page screenshot
- Roboflow: Ashby confirmation page screenshot
- SentiLink: Ashby confirmation page screenshot
- Slang AI: LinkedIn "Applied" status + confirmation
- RevPartners: LinkedIn "Applied" status + confirmation
- CaptivateIQ: ATS confirmation page screenshot
- HockeyStack: ATS confirmation page screenshot or LinkedIn applied status

After completing each manual application, update the `status` field in `data/gtm_tracker.csv` and regenerate the site data.
