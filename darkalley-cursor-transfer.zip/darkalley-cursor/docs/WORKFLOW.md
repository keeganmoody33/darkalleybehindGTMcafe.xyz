# GTM Job Hunt OS — Full Workflow

**9-step systematic process from role discovery to proof of application.**

The constraint: never mark anything Applied without proof. The principle: treat the job search like a GTM campaign — segment, score, personalize, execute, track.

---

## Step 1: COLLECT

**Goal:** Surface every active GTM Engineer role posted in the last 30 days.

**Sources (in priority order):**
1. **LinkedIn Jobs** — Largest index, best for filtering by remote/date
2. **Indeed** — Best for salary transparency (many roles disclose comp here that LinkedIn doesn't)
3. **BuiltIn** — Strongest for startup/tech companies
4. **Wellfound (AngelList)** — Early-stage companies, often pre-Series B

**Search terms (run all of these):**
- "GTM Engineer"
- "GTM Engineer" remote
- "GTM Automation Engineer"
- "GTM AI Engineer"
- "GTM Systems Engineer"
- "Revenue Operations GTM"
- "RevOps GTM Engineer"
- "Sales Engineer GTM"
- "Founding GTM Engineer"

**Filters:**
- Date posted: Last 7 days (refresh weekly), or Last 30 days for broader sweeps
- Remote: Yes / Remote (platform-dependent filter naming)
- Experience level: Mid-senior / Senior (filter out entry-level and director+)

**Output:** Raw list of company + title + URL. No scoring yet.

---

## Step 2: DEDUPLICATE

**Goal:** One canonical record per company+role combination.

**Rules:**
- Match on: `company name` + `role title` (normalized — "GTM Engineer" and "GTM Engineer - Revenue Operations" at the same company = different roles)
- Keep the best source URL: Direct ATS link > LinkedIn > Indeed > BuiltIn > Wellfound
- If same role is on multiple sources, keep the one with most detail (JD, salary, etc.)
- Mark duplicates as skipped, don't delete — audit trail matters

**Common duplicate sources:**
- Same role cross-posted on LinkedIn AND Indeed AND BuiltIn
- Recruiter re-posting a company's role under their own listing
- Role reposted under a slightly different title (check company + JD content)

---

## Step 3: SCORE

**Goal:** Apply the 6-dimension scoring rubric to every deduplicated role.

**Scoring dimensions** (see `docs/SCORING_RUBRIC.md` for full detail):
1. Title alignment (0–25)
2. Technical GTM systems focus (0–20)
3. Automation/AI emphasis (0–20)
4. Company type (0–15)
5. Seniority fit (0–10)
6. Remote-first (0–10)

**Process:**
- Read the full job description (don't just score from title)
- Check the company's website if the JD is sparse
- Note specific risks/gaps that might affect fit (domain expertise, seniority misalign, hybrid requirement)
- Record match_reasons (pipe-delimited, top 3 signals) and gaps_risks (pipe-delimited, top 2 concerns)
- Enter all data into `data/gtm_tracker.csv`

**Time budget per role:** 5–10 minutes max for scoring. Don't overthink it — the rubric exists so you're not re-deciding criteria every time.

---

## Step 4: TRIAGE

**Goal:** Route each role into the right action bucket automatically based on score.

| Score | Action | Description |
|---|---|---|
| 90+ | `auto-apply` | Submit without additional deliberation |
| 75–89 | `review-first` | Human review + approval required before submitting |
| <75 | `skip` | Do not apply. Log it and move on. |

**The skip threshold is a feature, not a bug.** Applying to 50 roles with identical notes wastes everyone's time. The rubric concentrates effort on the highest-fit roles.

**Triage output:** `action` field in gtm_tracker.csv set to `auto-apply`, `review-first`, or `skip`.

---

## Step 5: PERSONALIZE

**Goal:** Write a custom 75-word cover note for every role that will be applied to (score 75+).

**Format:** 75 words, first-person, no fluff. Connects Keegan's specific experience to the specific role and company. References real work, real tools, real results.

**Source of truth for facts:** `data/resume.md` — only pull claims from the resume. No fabrication.

**Formula:**
1. Name the company + role explicitly (1 sentence)
2. Connect Keegan's most relevant specific experience to what the role needs (2–3 sentences)
3. Reference the portfolio (lecturesfrom.com) as signal (1 sentence)
4. One closing connector sentence about fit

**Anti-patterns to avoid:**
- Generic opener: "I'm excited to apply for..."
- Restating the job description back to them
- Listing technologies without connecting them to outcomes
- Exceeding 80 words (75 is the target)

**Output:** One `custom_note` per role, stored in `docs/COVER_NOTES.md`.

---

## Step 6: APPROVE

**Goal:** Gate on a human decision before submitting.

| Score | Approval required? |
|---|---|
| 90+ (auto-apply) | No — submit immediately after cover note is ready |
| 75–89 (review-first) | Yes — human reviews approval card and confirms |
| <75 (skip) | N/A — never submitted |

**Approval card format:**
```
APPROVAL_CARD
company: [Company]
role: [Role Title]
fit_score: [Score]
action: [auto-apply or review-first]
why_match: [Top 3 match reasons]
risk: [Top 2 risks]
resume_variant: [Resume filename]
custom_note: [75-word note]
proof_plan: [How will we confirm submission?]
```

Approval cards for all 10 active applications are in `docs/COVER_NOTES.md`.

---

## Step 7: APPLY

**Goal:** Submit the application via the most direct ATS path available.

**ATS priority order:**
1. **Greenhouse** — Direct link: `boards.greenhouse.io/[company]/jobs/[id]`
2. **Ashby** — Direct link: `jobs.ashbyhq.com/[company]/[job-id]/application`
3. **Lever** — Direct link: `jobs.lever.co/[company]/[job-id]/apply`
4. **Workday** — Direct apply link from job listing
5. **LinkedIn Easy Apply** — Use only if no direct ATS exists
6. **Company careers page** — Direct form if no ATS middleware

**Submit with:**
- Resume: `KMOODY_02-2026_RESUME` (PDF version of `data/resume.md`)
- Cover note: The 75-word custom note from the approval card
- LinkedIn URL: linkedin.com/in/keeganmoody33 (if required)
- Portfolio URL: lecturesfrom.com/keeganmoody33 (if required)

**Blocker handling:**
- reCAPTCHA blocking automated submission → flag as "Blocked - reCAPTCHA", log the direct ATS URL in APPLICATION_STATUS.md, submit manually
- Resume upload failing → flag as "Blocked - Resume Upload", log URL for manual submission
- Verification email required (Greenhouse) → flag as "Verification Pending"

---

## Step 8: PROOF

**Non-negotiable rule: Never mark `status: Applied` without proof.**

**Acceptable proof (in order of strength):**
1. Screenshot of ATS confirmation page ("Your application has been submitted")
2. ATS confirmation email received
3. "Applied" status in LinkedIn Easy Apply history
4. Application visible in ATS candidate portal

**If proof is not immediately available:**
- Set status to `Verification Pending`
- Note the verification method needed (e.g. "Greenhouse email code required")
- Check email and complete verification before marking Applied

---

## Step 9: TRACK

**Goal:** Update the tracker and site so the public record stays accurate.

**After each application:**
1. Update `status` field in `data/gtm_tracker.csv`
2. Run `bash scripts/csv-to-js.sh` → update TRACKER_DATA in `app.js`
3. Update `docs/APPLICATION_STATUS.md` with current state + any blockers
4. Deploy the updated site

**Ongoing tracking (after Applied):**
- `Interviewing` — Update status if recruiter/hiring manager reaches out
- `Rejected` — Update status when rejection received (email, ATS portal, LinkedIn)
- `Offer` — Update status. Close the loop.

**Site stats are computed dynamically** from TRACKER_DATA in app.js. Updating the CSV and regenerating will automatically update the stats bar on the site.

---

## Workflow State Machine

```
NEW ROLE FOUND
     ↓
COLLECT → DEDUPLICATE → SCORE
                           ↓
                    score < 75? → SKIP (logged, not applied)
                           ↓
                    score 75-89? → REVIEW-FIRST → [human approval]
                           ↓                          ↓
                    score 90+? → AUTO-APPLY        REJECTED → SKIP
                           ↓                          ↓
                    PERSONALIZE (write 75-word note)
                           ↓
                    APPROVE (auto for 90+, human for 75-89)
                           ↓
                    APPLY (Greenhouse > Ashby > Lever > LinkedIn)
                           ↓
                    BLOCKER? → Flag + log for manual submit
                           ↓
                    PROOF (screenshot / confirmation email)
                           ↓
                    TRACK (update CSV → regenerate JS → deploy)
                           ↓
                    MONITOR (Interviewing / Rejected / Offer)
```
