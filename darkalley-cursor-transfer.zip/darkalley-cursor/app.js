/* app.js — Dark Alley Behind GTM Cafe */

// ===== TRACKER DATA (embedded from CSV) =====
const TRACKER_DATA = [
  {
    "company": "Dagster Labs",
    "title": "GTM Engineer",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/viewjob?jk=45a4c907ba0d95a7",
    "remote": "Yes",
    "salary": "$135,000 - $180,000/year",
    "posted_date": "Not specified",
    "fit_score": 92,
    "action": "auto-apply",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (dagster labs) | AI-native company with GTM automation context",
    "gaps_risks": "No strong explicit ATS job description available to verify full requirements | Role requirements not fully disclosed in job listing",
    "status": "Not Started"
  },
  {
    "company": "Slang AI",
    "title": "GTM Engineer - Revenue Operations",
    "source": "LinkedIn",
    "apply_url": "https://www.linkedin.com/jobs/view/gtm-engineer-revenue-operations-at-slang-ai-4380715014",
    "remote": "Remote",
    "salary": "Not listed",
    "posted_date": "3 weeks ago",
    "fit_score": 91,
    "action": "auto-apply",
    "match_reasons": "Close GTM Engineer variant | Strong technical GTM systems company (slang ai) | AI-native company with GTM automation context",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "RevPartners",
    "title": "GTM Engineer",
    "source": "LinkedIn",
    "apply_url": "https://www.linkedin.com/jobs/view/gtm-engineer-at-revpartners-4382218617",
    "remote": "Remote",
    "salary": "Not listed",
    "posted_date": "2 weeks ago",
    "fit_score": 88,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (revpartners) | AI-native/B2B SaaS/sales tech company",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "G2",
    "title": "GTM Engineer",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/viewjob?jk=ad39c861d2b5e1e1",
    "remote": "Yes",
    "salary": "$110,000 - $175,000/year",
    "posted_date": "Not specified",
    "fit_score": 88,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (g2) | AI-native/B2B SaaS/sales tech company",
    "gaps_risks": "No strong explicit ATS job description available to verify full requirements | Role requirements not fully disclosed in job listing",
    "status": "Not Started"
  },
  {
    "company": "PandaDoc",
    "title": "GTM Engineer",
    "source": "LinkedIn",
    "apply_url": "https://www.linkedin.com/jobs/view/gtm-engineer-at-pandadoc-4369211319",
    "remote": "Remote",
    "salary": "Not listed",
    "posted_date": "1 week ago",
    "fit_score": 86,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (pandadoc) | AI-native/B2B SaaS/sales tech company",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "Unstructured",
    "title": "GTM Engineer, Operations",
    "source": "LinkedIn",
    "apply_url": "https://www.linkedin.com/jobs/view/gtm-engineer-operations-at-unstructured-4388381035",
    "remote": "Remote",
    "salary": "Not listed",
    "posted_date": "1 week ago",
    "fit_score": 86,
    "action": "review-first",
    "match_reasons": "Close GTM Engineer variant | AI-native company with GTM automation context | Strong technical GTM systems company (unstructured)",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "Roboflow",
    "title": "RevOps GTM Engineer",
    "source": "BuiltIn",
    "apply_url": "https://builtin.com/job/revops-gtm-engineer/8882108",
    "remote": "In-Office or Remote",
    "salary": "Not listed",
    "posted_date": "4 Days Ago",
    "fit_score": 86,
    "action": "review-first",
    "match_reasons": "Close GTM Engineer variant | Strong technical GTM systems company (roboflow) | AI-native company with GTM automation context",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | Hybrid/in-office requirement \u2013 location-dependent",
    "status": "Not Started"
  },
  {
    "company": "SentiLink",
    "title": "Go-To-Market (GTM) Engineer",
    "source": "LinkedIn",
    "apply_url": "https://www.linkedin.com/jobs/view/go-to-market-gtm-engineer-at-sentilink-4391776545",
    "remote": "Remote",
    "salary": "Not listed",
    "posted_date": "2 days ago",
    "fit_score": 86,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (sentilink) | AI-native/B2B SaaS/sales tech company",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | Healthcare/compliance domain may require industry-specific experience",
    "status": "Not Started"
  },
  {
    "company": "CaptivateIQ",
    "title": "GTM Engineer",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/viewjob?jk=2933c05b3e8a52c9",
    "remote": "Yes (Hybrid in-office 3 days/week)",
    "salary": "$115,000 - $185,000/year",
    "posted_date": "Not specified",
    "fit_score": 86,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (captivateiq) | AI-native/B2B SaaS/sales tech company",
    "gaps_risks": "Hybrid/in-office requirement \u2013 location-dependent | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "HockeyStack",
    "title": "Sales Engineer, GTM AI",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/q-gtm-engineer-l-remote-jobs.html",
    "remote": "Yes",
    "salary": "$200,000 - $250,000/year",
    "posted_date": "Not specified",
    "fit_score": 86,
    "action": "review-first",
    "match_reasons": "AI/automation explicit in title | Strong technical GTM systems company (hockeystack) | GTM in title with qualifier",
    "gaps_risks": "No strong explicit ATS job description available to verify full requirements | Role requirements not fully disclosed in job listing",
    "status": "Not Started"
  },
  {
    "company": "Attentive",
    "title": "GTM Engineer",
    "source": "LinkedIn",
    "apply_url": "https://www.linkedin.com/jobs/view/gtm-engineer-at-attentive-4389964157",
    "remote": "Remote",
    "salary": "Not listed",
    "posted_date": "5 days ago",
    "fit_score": 85,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (attentive) | AI-native/B2B SaaS/sales tech company",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "Vercel",
    "title": "GTM Engineer",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/viewjob?jk=2d7759150a9eddd5",
    "remote": "Yes",
    "salary": "$180,000 - $310,000/year",
    "posted_date": "Not specified",
    "fit_score": 84,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | AI-native/B2B SaaS/sales tech company | Strong technical GTM systems company (vercel)",
    "gaps_risks": "No strong explicit ATS job description available to verify full requirements | Role requirements not fully disclosed in job listing",
    "status": "Not Started"
  },
  {
    "company": "Seamless",
    "title": "GTM Automation Engineer",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/viewjob?jk=1b52470f59e76f94",
    "remote": "Yes",
    "salary": "Not listed",
    "posted_date": "Not specified",
    "fit_score": 84,
    "action": "review-first",
    "match_reasons": "GTM automation/AI/growth engineer title | AI/automation explicit in title | Strong technical GTM systems company (seamless)",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "Unframe AI",
    "title": "GTM Engineer",
    "source": "BuiltIn",
    "apply_url": "https://builtin.com/job/gtm-engineer/8651539",
    "remote": "In-Office or Remote",
    "salary": "Not listed",
    "posted_date": "Reposted 11 Hours Ago",
    "fit_score": 83,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | AI-native company with GTM automation context | AI-native/B2B SaaS/sales tech company",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | Hybrid/in-office requirement \u2013 location-dependent",
    "status": "Not Started"
  },
  {
    "company": "Revic",
    "title": "Founding GTM AI Engineer",
    "source": "BuiltIn",
    "apply_url": "https://builtin.com/job/founding-gtm-ai-engineer/8165832",
    "remote": "In-Office or Remote",
    "salary": "Not listed",
    "posted_date": "Reposted 3 Days Ago",
    "fit_score": 83,
    "action": "review-first",
    "match_reasons": "GTM automation/AI/growth engineer title | AI/automation explicit in title | Strong technical GTM systems company (revic)",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | Hybrid/in-office requirement \u2013 location-dependent",
    "status": "Not Started"
  },
  {
    "company": "Ceros",
    "title": "GTM Systems Engineer",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/q-gtm-engineer-l-remote-jobs.html",
    "remote": "Yes",
    "salary": "$115,000 - $150,000/year",
    "posted_date": "Not specified",
    "fit_score": 83,
    "action": "review-first",
    "match_reasons": "Strong technical GTM systems company (ceros) | GTM Systems Engineer title | Systems/workflow engineering focus",
    "gaps_risks": "No strong explicit ATS job description available to verify full requirements | Role requirements not fully disclosed in job listing",
    "status": "Not Started"
  },
  {
    "company": "Wrapbook",
    "title": "GTM Systems Engineer",
    "source": "LinkedIn",
    "apply_url": "https://www.linkedin.com/jobs/view/gtm-systems-engineer-at-wrapbook-4382335541",
    "remote": "Remote",
    "salary": "Not listed",
    "posted_date": "1 day ago",
    "fit_score": 82,
    "action": "review-first",
    "match_reasons": "Strong technical GTM systems company (wrapbook) | GTM Systems Engineer title | Systems/workflow engineering focus",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "TigerData",
    "title": "GTM AI Engineer",
    "source": "BuiltIn",
    "apply_url": "https://builtin.com/job/gtm-ai-engineer/8894225",
    "remote": "In-Office or Remote",
    "salary": "Not listed",
    "posted_date": "3 Days Ago",
    "fit_score": 82,
    "action": "review-first",
    "match_reasons": "GTM automation/AI/growth engineer title | AI/automation explicit in title | AI-native/B2B SaaS/sales tech company",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | Hybrid/in-office requirement \u2013 location-dependent",
    "status": "Not Started"
  },
  {
    "company": "2X",
    "title": "GTM Engineer",
    "source": "LinkedIn",
    "apply_url": "https://www.linkedin.com/jobs/view/gtm-engineer-at-2x-4378539250",
    "remote": "Remote",
    "salary": "Not listed",
    "posted_date": "3 weeks ago",
    "fit_score": 80,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (2x) | Standard GTM role with some automation context",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | Company is early-stage or recruiter-based \u2013 role details may be vague",
    "status": "Not Started"
  },
  {
    "company": "Payabli",
    "title": "GTM Engineer",
    "source": "BuiltIn",
    "apply_url": "https://builtin.com/job/gtm-engineer/8598128",
    "remote": "Remote",
    "salary": "Not listed",
    "posted_date": "Reposted 6 Days Ago",
    "fit_score": 80,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (payabli) | Standard GTM role with some automation context",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "LeanScale",
    "title": "GTM Engineer",
    "source": "Wellfound",
    "apply_url": "https://wellfound.com/jobs/3976412-gtm-engineer",
    "remote": "Remote \u2014 United States",
    "salary": "Not listed",
    "posted_date": "~2026-03-23",
    "fit_score": 80,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (leanscale) | Standard GTM role with some automation context",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | Company is early-stage or recruiter-based \u2013 role details may be vague",
    "status": "Not Started"
  },
  {
    "company": "Apollo.io",
    "title": "Revenue Operations, GTM Engineer",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/q-revenue-operations-l-remote-jobs.html",
    "remote": "Yes",
    "salary": "$155,000 - $175,000/year",
    "posted_date": "Not specified",
    "fit_score": 80,
    "action": "review-first",
    "match_reasons": "Strong technical GTM systems company (apollo.io) | GTM in title with qualifier | AI-native/B2B SaaS/sales tech company",
    "gaps_risks": "No strong explicit ATS job description available to verify full requirements | Role requirements not fully disclosed in job listing",
    "status": "Not Started"
  },
  {
    "company": "Beautiful.ai",
    "title": "GTM Engineer",
    "source": "LinkedIn",
    "apply_url": "https://www.linkedin.com/jobs/view/gtm-engineer-at-beautiful-ai-4382353379",
    "remote": "Remote (filter applied)",
    "salary": "Not listed",
    "posted_date": "3 weeks ago",
    "fit_score": 79,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (beautiful.ai) | Standard GTM role with some automation context",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "Solv.",
    "title": "GTM Engineer",
    "source": "LinkedIn",
    "apply_url": "https://www.linkedin.com/jobs/view/gtm-engineer-at-solv-4376987900",
    "remote": "Remote",
    "salary": "Not listed",
    "posted_date": "1 week ago",
    "fit_score": 79,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (solv.) | Standard GTM role with some automation context",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "Stedi",
    "title": "GTM Engineer",
    "source": "BuiltIn",
    "apply_url": "https://builtin.com/job/growth/7749974",
    "remote": "In-Office or Remote",
    "salary": "Not listed",
    "posted_date": "Reposted 2 Days Ago",
    "fit_score": 79,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | AI-native/B2B SaaS/sales tech company | Strong technical GTM systems company (stedi)",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | Hybrid/in-office requirement \u2013 location-dependent",
    "status": "Not Started"
  },
  {
    "company": "Owner",
    "title": "Analytics Engineer, GTM",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/viewjob?jk=62bef2a28c16b3a6",
    "remote": "Yes",
    "salary": "$160,000 - $180,000/year",
    "posted_date": "Not specified",
    "fit_score": 79,
    "action": "review-first",
    "match_reasons": "Strong technical GTM systems company (owner) | GTM in title with qualifier | AI-native/B2B SaaS/sales tech company",
    "gaps_risks": "Analytics Engineer skew \u2013 may require SQL/dbt depth beyond GTM tooling | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "Recur Software",
    "title": "GTM Engineer",
    "source": "LinkedIn",
    "apply_url": "https://www.linkedin.com/jobs/view/gtm-engineer-at-recur-software-4383852596",
    "remote": "Remote",
    "salary": "Not listed",
    "posted_date": "2 weeks ago",
    "fit_score": 78,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (recur software) | Standard GTM role with some automation context",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "Built Technologies",
    "title": "GTM Engineer",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/viewjob?jk=0d61b40dbb0d02bf",
    "remote": "Yes",
    "salary": "$155,000 - $175,000/year",
    "posted_date": "Not specified",
    "fit_score": 78,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (built technologies) | Standard GTM role with some automation context",
    "gaps_risks": "No strong explicit ATS job description available to verify full requirements | Role requirements not fully disclosed in job listing",
    "status": "Not Started"
  },
  {
    "company": "Fullbay",
    "title": "GTM AI Engineer",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/q-gtm-engineer-l-remote-jobs.html",
    "remote": "Yes",
    "salary": "$114,529 - $140,299/year",
    "posted_date": "Not specified",
    "fit_score": 78,
    "action": "review-first",
    "match_reasons": "GTM automation/AI/growth engineer title | AI/automation explicit in title | Other SaaS company",
    "gaps_risks": "No strong explicit ATS job description available to verify full requirements | Role requirements not fully disclosed in job listing",
    "status": "Not Started"
  },
  {
    "company": "Anaconda, Inc.",
    "title": "GTM Engineer",
    "source": "LinkedIn",
    "apply_url": "https://www.linkedin.com/jobs/view/gtm-engineer-at-anaconda-inc-4389333295",
    "remote": "Remote",
    "salary": "Not listed",
    "posted_date": "6 days ago",
    "fit_score": 77,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (anaconda, inc.) | Standard GTM role with some automation context",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "Nash",
    "title": "GTM Engineer",
    "source": "LinkedIn",
    "apply_url": "https://www.linkedin.com/jobs/view/gtm-engineer-at-nash-4379214114",
    "remote": "Remote",
    "salary": "Not listed",
    "posted_date": "1 month ago",
    "fit_score": 77,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (nash) | Standard GTM role with some automation context",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "59 Pines",
    "title": "GTM Engineer: Facebook & Social Outreach Automation Specialist",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/viewjob?jk=183f818c1e9b7fa7",
    "remote": "Yes",
    "salary": "Up to $165,000/year",
    "posted_date": "Not specified",
    "fit_score": 76,
    "action": "review-first",
    "match_reasons": "Strong technical GTM systems company (59 pines) | GTM in title with qualifier | AI-native/B2B SaaS/sales tech company",
    "gaps_risks": "No strong explicit ATS job description available to verify full requirements | Role requirements not fully disclosed in job listing",
    "status": "Not Started"
  },
  {
    "company": "Vanta",
    "title": "Senior Analytics Engineer, GTM Analytics",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/viewjob?jk=d510d296bad46471",
    "remote": "Yes",
    "salary": "$161,000 - $189,000/year",
    "posted_date": "Not specified",
    "fit_score": 76,
    "action": "review-first",
    "match_reasons": "Strong technical GTM systems company (vanta) | GTM in title with qualifier | AI-native/B2B SaaS/sales tech company",
    "gaps_risks": "Healthcare/compliance domain may require industry-specific experience | Analytics Engineer skew \u2013 may require SQL/dbt depth beyond GTM tooling",
    "status": "Not Started"
  },
  {
    "company": "HIREXE",
    "title": "GTM Engineer",
    "source": "LinkedIn",
    "apply_url": "https://www.linkedin.com/jobs/view/gtm-engineer-at-hirexe-4392573159",
    "remote": "Remote",
    "salary": "Not listed",
    "posted_date": "1 hour ago",
    "fit_score": 75,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Moderate technical GTM alignment | Standard GTM role with some automation context",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | Company is early-stage or recruiter-based \u2013 role details may be vague",
    "status": "Not Started"
  },
  {
    "company": "COLOSSUS TECHNOLOGY GROUP",
    "title": "GTM Engineer",
    "source": "LinkedIn",
    "apply_url": "https://www.linkedin.com/jobs/view/gtm-engineer-4385958618",
    "remote": "Remote",
    "salary": "Not listed",
    "posted_date": "1 week ago",
    "fit_score": 75,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Moderate technical GTM alignment | Standard GTM role with some automation context",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | Company is early-stage or recruiter-based \u2013 role details may be vague",
    "status": "Not Started"
  },
  {
    "company": "Cracken",
    "title": "GTM Engineer",
    "source": "Wellfound",
    "apply_url": "https://wellfound.com/jobs/3996841-gtm-engineer",
    "remote": "Remote \u2014 Everywhere",
    "salary": "Not listed",
    "posted_date": "~2026-03-23",
    "fit_score": 75,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | AI-native/B2B SaaS/sales tech company | Strong technical GTM systems company (cracken)",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "Athennian",
    "title": "GTM Engineer",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/q-gtm-engineer-l-remote-jobs.html",
    "remote": "Yes",
    "salary": "Not listed",
    "posted_date": "Not specified",
    "fit_score": 75,
    "action": "review-first",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (athennian) | Standard GTM role with some automation context",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "PhrasIQ",
    "title": "Founding GTM Engineer",
    "source": "Wellfound",
    "apply_url": "https://wellfound.com/jobs/4036795-founding-gtm-engineer",
    "remote": "Remote \u2014 Everywhere",
    "salary": "Not listed",
    "posted_date": "2026-03-29",
    "fit_score": 74,
    "action": "skip",
    "match_reasons": "Close GTM Engineer variant | AI-native company with GTM automation context | AI-native/B2B SaaS/sales tech company",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "Redwood Software",
    "title": "GTM Engineer",
    "source": "BuiltIn",
    "apply_url": "https://builtin.com/job/gtm-engineer/7747944",
    "remote": "In-Office or Remote",
    "salary": "Not listed",
    "posted_date": "Reposted 4 Days Ago",
    "fit_score": 72,
    "action": "skip",
    "match_reasons": "Exact 'GTM Engineer' title match | Strong technical GTM systems company (redwood software) | Standard GTM role with some automation context",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | Hybrid/in-office requirement \u2013 location-dependent",
    "status": "Not Started"
  },
  {
    "company": "59 Pines",
    "title": "Lead GTM Engineer",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/viewjob?jk=23cb3e205faba719",
    "remote": "Yes",
    "salary": "Up to $275,000/year",
    "posted_date": "Not specified",
    "fit_score": 72,
    "action": "skip",
    "match_reasons": "Strong technical GTM systems company (59 pines) | GTM in title with qualifier | AI-native/B2B SaaS/sales tech company",
    "gaps_risks": "Staff/Lead level may expect broader platform ownership or team mentorship | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "GrackerAI",
    "title": "GTM Engineer (Inbound)",
    "source": "Wellfound",
    "apply_url": "https://wellfound.com/jobs/3962708-gtm-engineer-inbound",
    "remote": "Remote \u2014 Everywhere",
    "salary": "Not listed",
    "posted_date": "~2026-03-16",
    "fit_score": 71,
    "action": "skip",
    "match_reasons": "AI-native company with GTM automation context | GTM in title with qualifier | AI-native/B2B SaaS/sales tech company",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "Wrapbook",
    "title": "GTM Engineer (Pre-Sale)",
    "source": "LinkedIn",
    "apply_url": "https://www.linkedin.com/jobs/view/gtm-engineer-pre-sale-at-wrapbook-4365140304",
    "remote": "Remote",
    "salary": "Not listed",
    "posted_date": "3 days ago",
    "fit_score": 69,
    "action": "skip",
    "match_reasons": "GTM in title with qualifier | Strong technical GTM systems company (wrapbook) | Standard GTM role with some automation context",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | Pre-sale focus leans toward sales engineering vs. GTM systems builder",
    "status": "Not Started"
  },
  {
    "company": "DigiCert",
    "title": "Lead GTM Analytics Engineer",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/viewjob?jk=eb21c3968bfd8b4b",
    "remote": "Yes",
    "salary": "$160,000 - $170,000/year",
    "posted_date": "Not specified",
    "fit_score": 68,
    "action": "skip",
    "match_reasons": "Strong technical GTM systems company (digicert) | GTM in title with qualifier | Standard GTM role with some automation context",
    "gaps_risks": "Analytics Engineer skew \u2013 may require SQL/dbt depth beyond GTM tooling | Staff/Lead level may expect broader platform ownership or team mentorship",
    "status": "Not Started"
  },
  {
    "company": "Dropbox",
    "title": "CX Software Engineer, GTM Platforms",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/q-gtm-engineer-l-remote-jobs.html",
    "remote": "Yes",
    "salary": "$134,600 - $204,900/year",
    "posted_date": "Not specified",
    "fit_score": 67,
    "action": "skip",
    "match_reasons": "GTM in title with qualifier | Strong technical GTM systems company (dropbox) | Standard GTM role with some automation context",
    "gaps_risks": "CX platform role may prioritize customer-facing engineering over GTM automation | Role is adjacent to GTM \u2013 requires significant context-setting in application",
    "status": "Not Started"
  },
  {
    "company": "Jobgether",
    "title": "Senior GTM Engineer",
    "source": "LinkedIn",
    "apply_url": "https://www.linkedin.com/jobs/view/senior-gtm-engineer-at-jobgether-4391182031",
    "remote": "Remote",
    "salary": "Not listed",
    "posted_date": "3 days ago",
    "fit_score": 66,
    "action": "skip",
    "match_reasons": "Senior GTM Engineer title | Moderate technical GTM alignment | Standard GTM role with some automation context",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | Company is early-stage or recruiter-based \u2013 role details may be vague",
    "status": "Not Started"
  },
  {
    "company": "Valimail",
    "title": "Lead GTM Operations Engineer",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/q-gtm-engineer-l-remote-jobs.html",
    "remote": "Yes",
    "salary": "$155,000 - $185,000/year",
    "posted_date": "Not specified",
    "fit_score": 66,
    "action": "skip",
    "match_reasons": "GTM in title with qualifier | Strong technical GTM systems company (valimail) | Standard GTM role with some automation context",
    "gaps_risks": "Staff/Lead level may expect broader platform ownership or team mentorship | Role is adjacent to GTM \u2013 requires significant context-setting in application",
    "status": "Not Started"
  },
  {
    "company": "Rula",
    "title": "GTM Engineer (Remote)",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/viewjob?jk=6d8aeee97acdbd4e",
    "remote": "Yes",
    "salary": "$161,500 - $180,500/year",
    "posted_date": "Not specified",
    "fit_score": 63,
    "action": "skip",
    "match_reasons": "GTM in title with qualifier | Standard GTM role with some automation context | Other SaaS company",
    "gaps_risks": "Healthcare/compliance domain may require industry-specific experience | Role is adjacent to GTM \u2013 requires significant context-setting in application",
    "status": "Not Started"
  },
  {
    "company": "CBT Nuggets",
    "title": "Revenue Operations Engineer",
    "source": "Indeed",
    "apply_url": "https://www.indeed.com/q-revenue-engineer-l-remote-jobs.html",
    "remote": "Yes",
    "salary": "$80,000 - $100,000/year",
    "posted_date": "Not specified",
    "fit_score": 63,
    "action": "skip",
    "match_reasons": "Strong technical GTM systems company (cbt nuggets) | Adjacent GTM-related role | Standard GTM role with some automation context",
    "gaps_risks": "Role is adjacent to GTM \u2013 requires significant context-setting in application | No strong explicit ATS job description available to verify full requirements",
    "status": "Not Started"
  },
  {
    "company": "Eve",
    "title": "Software Engineer, Full Stack - GTM",
    "source": "BuiltIn",
    "apply_url": "https://builtin.com/job/senior-marketing-engineer/8457597",
    "remote": "Remote or Hybrid",
    "salary": "Not listed",
    "posted_date": "Reposted 13 Days Ago",
    "fit_score": 60,
    "action": "skip",
    "match_reasons": "GTM in title with qualifier | Moderate technical GTM alignment | Standard GTM role with some automation context",
    "gaps_risks": "Salary not disclosed \u2013 compensation expectations unknown | Hybrid/in-office requirement \u2013 location-dependent",
    "status": "Not Started"
  }
];

// ===== STATE =====
let currentSort = { key: 'fit_score', dir: 'desc' };
let expandedRows = new Set();

// ===== THEME TOGGLE =====
(function() {
  const toggle = document.querySelector('[data-theme-toggle]');
  const root = document.documentElement;
  let theme = 'dark'; // default dark
  root.setAttribute('data-theme', theme);

  if (toggle) {
    toggle.addEventListener('click', () => {
      theme = theme === 'dark' ? 'light' : 'dark';
      root.setAttribute('data-theme', theme);
      toggle.setAttribute('aria-label', 'Switch to ' + (theme === 'dark' ? 'light' : 'dark') + ' mode');
      toggle.innerHTML = theme === 'dark'
        ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>'
        : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
    });
  }
})();

// ===== HELPER: Parse salary for sorting =====
function parseSalary(salary) {
  if (!salary || salary === 'Not listed') return 0;
  const match = salary.match(/\$([\d,]+)/);
  if (match) return parseInt(match[1].replace(/,/g, ''), 10);
  return 0;
}

// ===== HELPER: Score badge class =====
function scoreClass(score) {
  if (score >= 85) return 'score-badge--green';
  if (score >= 75) return 'score-badge--yellow';
  return 'score-badge--red';
}

// ===== HELPER: Status pill class =====
function statusClass(status) {
  const map = {
    'Not Started': 'status-pill--not-started',
    'Applied': 'status-pill--applied',
    'Interviewing': 'status-pill--interviewing',
    'Rejected': 'status-pill--rejected',
    'Offer': 'status-pill--offer'
  };
  return map[status] || 'status-pill--not-started';
}

// ===== HELPER: Action badge class =====
function actionClass(action) {
  const map = {
    'auto-apply': 'action-badge--auto',
    'review-first': 'action-badge--review',
    'skip': 'action-badge--skip'
  };
  return map[action] || '';
}

// ===== HELPER: Action label =====
function actionLabel(action) {
  const map = {
    'auto-apply': 'Auto-Apply',
    'review-first': 'Review First',
    'skip': 'Skip'
  };
  return map[action] || action;
}

// ===== FILTER & SORT =====
function getFilteredData() {
  const searchVal = document.getElementById('search-input').value.toLowerCase();
  const scoreFilter = document.getElementById('filter-score').value;
  const statusFilter = document.getElementById('filter-status').value;
  const sourceFilter = document.getElementById('filter-source').value;
  const actionFilter = document.getElementById('filter-action').value;

  let data = TRACKER_DATA.filter(r => {
    // Search
    if (searchVal && !(r.company.toLowerCase().includes(searchVal) || r.title.toLowerCase().includes(searchVal))) {
      return false;
    }
    // Score
    if (scoreFilter === '85+' && r.fit_score < 85) return false;
    if (scoreFilter === '75-84' && (r.fit_score < 75 || r.fit_score > 84)) return false;
    if (scoreFilter === '<75' && r.fit_score >= 75) return false;
    // Status
    if (statusFilter !== 'all' && r.status !== statusFilter) return false;
    // Source
    if (sourceFilter !== 'all' && r.source !== sourceFilter) return false;
    // Action
    if (actionFilter !== 'all' && r.action !== actionFilter) return false;
    return true;
  });

  // Sort
  data.sort((a, b) => {
    let valA, valB;
    const key = currentSort.key;
    if (key === 'fit_score') {
      valA = a.fit_score;
      valB = b.fit_score;
    } else if (key === 'salary') {
      valA = parseSalary(a.salary);
      valB = parseSalary(b.salary);
    } else if (key === 'company') {
      valA = a.company.toLowerCase();
      valB = b.company.toLowerCase();
    } else if (key === 'title') {
      valA = a.title.toLowerCase();
      valB = b.title.toLowerCase();
    } else if (key === 'source') {
      valA = a.source.toLowerCase();
      valB = b.source.toLowerCase();
    } else if (key === 'status') {
      valA = a.status.toLowerCase();
      valB = b.status.toLowerCase();
    } else if (key === 'action') {
      valA = a.action;
      valB = b.action;
    } else {
      valA = a[key];
      valB = b[key];
    }

    if (typeof valA === 'string') {
      const cmp = valA.localeCompare(valB);
      return currentSort.dir === 'asc' ? cmp : -cmp;
    }
    return currentSort.dir === 'asc' ? valA - valB : valB - valA;
  });

  return data;
}

// ===== RENDER TABLE =====
function renderTable() {
  const data = getFilteredData();
  const tbody = document.getElementById('tracker-body');
  let html = '';

  if (data.length === 0) {
    html = '<tr><td colspan="8" class="no-results">No roles match your filters.</td></tr>';
  } else {
    data.forEach((r, i) => {
      const isExpanded = expandedRows.has(r.apply_url);
      const salaryDisplay = (!r.salary || r.salary === 'Not listed')
        ? '<span class="salary-text salary-text--none">Not listed</span>'
        : '<span class="salary-text">' + escapeHTML(r.salary) + '</span>';

      html += `<tr class="${isExpanded ? 'expanded' : ''}" data-url="${escapeHTML(r.apply_url)}">
        <td>
          <div class="company-name">${escapeHTML(r.company)}</div>
        </td>
        <td>
          <div class="role-title">${escapeHTML(r.title)}</div>
        </td>
        <td>
          <span class="score-badge ${scoreClass(r.fit_score)}">${r.fit_score}</span>
        </td>
        <td>${salaryDisplay}</td>
        <td><span class="source-text">${escapeHTML(r.source)}</span></td>
        <td><span class="status-pill ${statusClass(r.status)}">${escapeHTML(r.status)}</span></td>
        <td><span class="action-badge ${actionClass(r.action)}">${actionLabel(r.action)}</span></td>
        <td>
          <button class="row-expand-btn" onclick="toggleRow('${escapeHTML(r.apply_url)}')" aria-label="Expand details">
            ${isExpanded ? '−' : '+'}
          </button>
        </td>
      </tr>`;

      if (isExpanded) {
        const matches = r.match_reasons.split(' | ').filter(Boolean);
        const gaps = r.gaps_risks.split(' | ').filter(Boolean);
        html += `<tr class="detail-row">
          <td colspan="8">
            <div class="detail-content">
              <div>
                <h4>Match Reasons</h4>
                <ul>${matches.map(m => '<li>' + escapeHTML(m) + '</li>').join('')}</ul>
              </div>
              <div>
                <h4>Gaps &amp; Risks</h4>
                <ul>${gaps.map(g => '<li>' + escapeHTML(g) + '</li>').join('')}</ul>
              </div>
            </div>
            <div style="padding: 0 var(--space-6) var(--space-4);">
              <a href="${escapeHTML(r.apply_url)}" target="_blank" rel="noopener noreferrer" class="detail-apply-link">View Listing ↗</a>
            </div>
          </td>
        </tr>`;
      }
    });
  }

  tbody.innerHTML = html;

  // Update row count
  document.getElementById('row-count').textContent = `Showing ${data.length} of ${TRACKER_DATA.length} roles`;

  // Update sort indicators
  document.querySelectorAll('.tracker-table th').forEach(th => {
    th.classList.remove('sorted');
    const icon = th.querySelector('.sort-icon');
    if (icon) icon.textContent = '↕';
    if (th.dataset.sort === currentSort.key) {
      th.classList.add('sorted');
      if (icon) icon.textContent = currentSort.dir === 'asc' ? '↑' : '↓';
    }
  });
}

// ===== EXPAND/COLLAPSE ROW =====
function toggleRow(url) {
  if (expandedRows.has(url)) {
    expandedRows.delete(url);
  } else {
    expandedRows.add(url);
  }
  renderTable();
}

// ===== SORT HANDLER =====
document.querySelectorAll('.tracker-table th[data-sort]').forEach(th => {
  th.addEventListener('click', () => {
    const key = th.dataset.sort;
    if (currentSort.key === key) {
      currentSort.dir = currentSort.dir === 'asc' ? 'desc' : 'asc';
    } else {
      currentSort.key = key;
      currentSort.dir = key === 'fit_score' || key === 'salary' ? 'desc' : 'asc';
    }
    renderTable();
  });
});

// ===== FILTER HANDLERS =====
document.getElementById('search-input').addEventListener('input', renderTable);
document.getElementById('filter-score').addEventListener('change', renderTable);
document.getElementById('filter-status').addEventListener('change', renderTable);
document.getElementById('filter-source').addEventListener('change', renderTable);
document.getElementById('filter-action').addEventListener('change', renderTable);

// ===== POPULATE SOURCE FILTER =====
(function() {
  const sources = [...new Set(TRACKER_DATA.map(r => r.source))].sort();
  const select = document.getElementById('filter-source');
  sources.forEach(s => {
    const opt = document.createElement('option');
    opt.value = s;
    opt.textContent = s;
    select.appendChild(opt);
  });
})();

// ===== UPDATE STATS =====
function updateStats() {
  const total = TRACKER_DATA.length;
  const avgScore = Math.round(TRACKER_DATA.reduce((s, r) => s + r.fit_score, 0) / total);
  const autoApply = TRACKER_DATA.filter(r => r.action === 'auto-apply').length;
  const top = TRACKER_DATA.filter(r => r.fit_score >= 85).length;

  document.getElementById('stat-total').textContent = total;
  document.getElementById('stat-avg-score').textContent = avgScore;
  document.getElementById('stat-auto').textContent = autoApply;
  document.getElementById('stat-top').textContent = top;
}

// ===== SCROLL REVEAL =====
(function() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

  document.querySelectorAll('.fade-in').forEach(el => observer.observe(el));
})();

// ===== ESCAPE HTML =====
function escapeHTML(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ===== INIT =====
updateStats();
renderTable();
